# 3 PROMPTS PRATICOS — REELS PARA BARBEARIAS
Preencha todos os campos entre colchetes com informacoes VERDADEIRAS. Nao invente precos, horarios, clientes ou depoimentos.

## 01 - Reel de agendamento
Atue como roteirista para a barbearia [NOME], localizada em [BAIRRO]. Crie um roteiro vertical de 8 a 12 segundos com 3 cenas viaveis de filmar no proprio negocio, um gancho nos primeiros 3 segundos e um CTA claro para agendar pelo [CANAL OFICIAL]. Use apenas estes servicos [SERVICOS REAIS] e horarios [HORARIOS REAIS]. Forneca texto de tela e legenda; quando faltar informacao marque [CONFERIR].

## 02 - Antes e depois responsavel
Crie uma sequencia de 15 segundos para mostrar um corte executado pela propria barbearia [NOME]. Antes de usar imagens de clientes exija autorizacao documentada. Estruture introducao, processo e resultado sem filtros que distorcam o servico prestado. Entregue 3 opcoes de gancho, legenda objetiva e CTA.

## 03 - Oferta de servico criativo
Redija uma proposta curta, individualizada e respeitosa para oferecer criacao de [NUMERO] Reels originais por [PRECO VALIDADO] a uma barbearia que CONSENTIU receber o contato. Inclua escopo, prazo, revisoes, necessidade de imagens autorizadas, entrega e licenca de uso; nao prometa viralizacao ou novos clientes.
